package ec.udla.iswz2202.bikestoreasync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BikestoreAsyncApplication {

	public static void main(String[] args) {
		SpringApplication.run(BikestoreAsyncApplication.class, args);
	}

}
