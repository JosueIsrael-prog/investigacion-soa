package ec.udla.iswz2202.bikestoreasync;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BikestoreAsyncApplicationTests {

	@Test
	void contextLoads() {
	}

}
